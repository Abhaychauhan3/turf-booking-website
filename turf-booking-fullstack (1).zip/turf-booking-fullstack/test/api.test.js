import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
import { rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, '..');
const dbPath = path.join(root, 'test-turf.db');
const port = 4512;

await rm(dbPath, { force: true });

const server = spawn(process.execPath, ['src/server.js'], {
  cwd: root,
  env: { ...process.env, PORT: String(port), DB_PATH: dbPath, OWNER_PIN: '1234' },
  stdio: ['ignore', 'pipe', 'pipe']
});

function stop() {
  server.kill('SIGINT');
}

process.on('exit', stop);

async function waitForServer() {
  for (let i = 0; i < 50; i++) {
    try {
      const res = await fetch(`http://localhost:${port}/api/health`);
      if (res.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error('Server did not start.');
}

async function api(pathname, options = {}) {
  const response = await fetch(`http://localhost:${port}${pathname}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'x-owner-pin': '1234', ...(options.headers || {}) }
  });
  const data = await response.json();
  return { status: response.status, data };
}

await waitForServer();

let result = await api('/api/config');
assert.equal(result.status, 200);
assert.equal(result.data.sports.length, 2);

result = await api('/api/availability?date=2026-06-19&sport=football');
assert.equal(result.status, 200);
assert.equal(result.data.slots.length, 18);
assert.equal(result.data.slots.find((slot) => slot.slot === '19:00').price, 1200);

result = await api('/api/bookings', {
  method: 'POST',
  body: JSON.stringify({ date: '2026-06-19', slot: '19:00', sport: 'football', customerName: 'Abhay', phone: '9876543210' })
});
assert.equal(result.status, 201);
assert.match(result.data.booking.bookingId, /^GFT\d{6}$/);

result = await api('/api/bookings', {
  method: 'POST',
  body: JSON.stringify({ date: '2026-06-19', slot: '19:00', sport: 'football', customerName: 'Another', phone: '9876543211' })
});
assert.equal(result.status, 409);

const racers = await Promise.all(Array.from({ length: 8 }, (_, i) => api('/api/bookings', {
  method: 'POST',
  body: JSON.stringify({ date: '2026-06-19', slot: '20:00', sport: 'football', customerName: `Racer ${i}`, phone: `98765432${10 + i}` })
})));
assert.equal(racers.filter((r) => r.status === 201).length, 1);
assert.equal(racers.filter((r) => r.status === 409).length, 7);

result = await api('/api/admin/block-slot', {
  method: 'POST',
  body: JSON.stringify({ date: '2026-06-19', slot: '21:00', sport: 'football', block: true, reason: 'Maintenance' })
});
assert.equal(result.status, 200);
assert.equal(result.data.slots.find((slot) => slot.slot === '21:00').status, 'blocked');

result = await api('/api/bookings', {
  method: 'POST',
  body: JSON.stringify({ date: '2026-06-19', slot: '21:00', sport: 'football', customerName: 'Blocked Test', phone: '9876543220' })
});
assert.equal(result.status, 409);

result = await api('/api/bookings?date=2026-06-19');
assert.equal(result.status, 200);
assert.ok(result.data.bookings.length >= 2);

const homepage = await fetch(`http://localhost:${port}/`);
assert.equal(homepage.status, 200);
assert.match(await homepage.text(), /GreenField Turf Booking/);

stop();
await rm(dbPath, { force: true });
console.log('All full-stack API tests passed ✅');
