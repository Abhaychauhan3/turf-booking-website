import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import { TIME_SLOTS, getPrice } from './config.js';

function rowToBooking(row) {
  if (!row) return null;
  return {
    id: row.id,
    bookingId: row.booking_id,
    date: row.booking_date,
    slot: row.slot,
    sport: row.sport,
    customerName: row.customer_name,
    phone: row.phone,
    price: row.price,
    paymentStatus: row.payment_status,
    createdAt: row.created_at
  };
}

export function createBookingId() {
  return 'GFT' + crypto.randomInt(100000, 999999);
}

export function initDatabase(dbPath = './turf.db') {
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');

  db.exec(`
    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_id TEXT NOT NULL UNIQUE,
      booking_date TEXT NOT NULL,
      slot TEXT NOT NULL,
      sport TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      price INTEGER NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'paid',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (booking_date, slot, sport)
    );

    CREATE TABLE IF NOT EXISTS blocked_slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      booking_date TEXT NOT NULL,
      slot TEXT NOT NULL,
      sport TEXT NOT NULL,
      reason TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (booking_date, slot, sport)
    );
  `);

  const statements = {
    bookingsByDateSport: db.prepare(`
      SELECT * FROM bookings
      WHERE booking_date = ? AND sport = ?
      ORDER BY slot ASC
    `),
    bookingsByDate: db.prepare(`
      SELECT * FROM bookings
      WHERE booking_date = ?
      ORDER BY slot ASC, sport ASC
    `),
    blockedByDateSport: db.prepare(`
      SELECT * FROM blocked_slots
      WHERE booking_date = ? AND sport = ?
      ORDER BY slot ASC
    `),
    findBookingSlot: db.prepare(`
      SELECT * FROM bookings
      WHERE booking_date = ? AND slot = ? AND sport = ?
      LIMIT 1
    `),
    findBlockedSlot: db.prepare(`
      SELECT * FROM blocked_slots
      WHERE booking_date = ? AND slot = ? AND sport = ?
      LIMIT 1
    `),
    insertBooking: db.prepare(`
      INSERT INTO bookings
        (booking_id, booking_date, slot, sport, customer_name, phone, price, payment_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `),
    getBookingById: db.prepare(`
      SELECT * FROM bookings WHERE booking_id = ? LIMIT 1
    `),
    upsertBlockedSlot: db.prepare(`
      INSERT INTO blocked_slots (booking_date, slot, sport, reason)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(booking_date, slot, sport) DO UPDATE SET
        reason = excluded.reason
    `),
    deleteBlockedSlot: db.prepare(`
      DELETE FROM blocked_slots
      WHERE booking_date = ? AND slot = ? AND sport = ?
    `)
  };

  function getAvailability(date, sport) {
    const bookings = statements.bookingsByDateSport.all(date, sport);
    const blocked = statements.blockedByDateSport.all(date, sport);

    const bookedSlots = new Map(bookings.map((booking) => [booking.slot, booking]));
    const blockedSlots = new Map(blocked.map((block) => [block.slot, block]));

    return TIME_SLOTS.map((slot) => {
      if (bookedSlots.has(slot)) {
        const booking = bookedSlots.get(slot);
        return {
          slot,
          status: 'booked',
          price: booking.price,
          bookingId: booking.booking_id,
          customerName: booking.customer_name,
          phone: booking.phone
        };
      }
      if (blockedSlots.has(slot)) {
        return {
          slot,
          status: 'blocked',
          price: getPrice(sport, slot),
          reason: blockedSlots.get(slot).reason || 'Blocked by owner'
        };
      }
      return {
        slot,
        status: 'open',
        price: getPrice(sport, slot)
      };
    });
  }

  function createBooking({ date, slot, sport, customerName, phone, paymentStatus = 'paid' }) {
    const price = getPrice(sport, slot);
    const bookingId = createBookingId();

    db.exec('BEGIN IMMEDIATE;');
    try {
      const existingBooking = statements.findBookingSlot.get(date, slot, sport);
      if (existingBooking) {
        db.exec('ROLLBACK;');
        return { ok: false, code: 'SLOT_ALREADY_BOOKED', message: 'This slot is already booked.' };
      }

      const existingBlock = statements.findBlockedSlot.get(date, slot, sport);
      if (existingBlock) {
        db.exec('ROLLBACK;');
        return { ok: false, code: 'SLOT_BLOCKED', message: 'This slot is blocked by the owner.' };
      }

      statements.insertBooking.run(
        bookingId,
        date,
        slot,
        sport,
        customerName.trim(),
        phone,
        price,
        paymentStatus
      );

      db.exec('COMMIT;');
      const booking = statements.getBookingById.get(bookingId);
      return { ok: true, booking: rowToBooking(booking) };
    } catch (error) {
      try { db.exec('ROLLBACK;'); } catch {}
      if (String(error.message).includes('UNIQUE')) {
        return { ok: false, code: 'SLOT_ALREADY_BOOKED', message: 'This slot is already booked.' };
      }
      throw error;
    }
  }

  function getBookings(date) {
    return statements.bookingsByDate.all(date).map(rowToBooking);
  }

  function setBlockedSlot({ date, slot, sport, block, reason = '' }) {
    db.exec('BEGIN IMMEDIATE;');
    try {
      if (block) {
        const existingBooking = statements.findBookingSlot.get(date, slot, sport);
        if (existingBooking) {
          db.exec('ROLLBACK;');
          return { ok: false, code: 'SLOT_ALREADY_BOOKED', message: 'A customer already booked this slot.' };
        }
        statements.upsertBlockedSlot.run(date, slot, sport, reason || 'Blocked by owner');
      } else {
        statements.deleteBlockedSlot.run(date, slot, sport);
      }
      db.exec('COMMIT;');
      return { ok: true, availability: getAvailability(date, sport) };
    } catch (error) {
      try { db.exec('ROLLBACK;'); } catch {}
      throw error;
    }
  }

  return {
    getAvailability,
    createBooking,
    getBookings,
    setBlockedSlot,
    close: () => db.close()
  };
}
