export const SPORTS = [
  { id: 'football', label: 'Football (5-a-side)', dayPrice: 800, nightPrice: 1200 },
  { id: 'cricket', label: 'Box Cricket', dayPrice: 900, nightPrice: 1400 }
];

export const TIME_SLOTS = [
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'
];

export const BUSINESS = {
  name: 'GreenField Turf',
  city: 'Lucknow',
  openLabel: 'Open 6 AM – 12 AM',
  phone: '+91 98765 43210',
  address: 'Lucknow, Uttar Pradesh'
};

export function isNight(slot) {
  const hour = Number(slot.split(':')[0]);
  return hour >= 18 || hour < 6;
}

export function getSport(sportId) {
  return SPORTS.find((sport) => sport.id === sportId);
}

export function getPrice(sportId, slot) {
  const sport = getSport(sportId);
  if (!sport) return null;
  return isNight(slot) ? sport.nightPrice : sport.dayPrice;
}

export function isValidDateKey(date) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(date));
}

export function isValidSlot(slot) {
  return TIME_SLOTS.includes(slot);
}

export function isValidSport(sport) {
  return SPORTS.some((s) => s.id === sport);
}

export function isValidIndianPhone(phone) {
  return /^[6-9]\d{9}$/.test(String(phone));
}
