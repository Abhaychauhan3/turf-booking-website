import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BUSINESS, SPORTS, TIME_SLOTS, isValidDateKey, isValidIndianPhone, isValidSlot, isValidSport } from './config.js';
import { initDatabase } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');
const publicDir = path.join(projectRoot, 'public');

const PORT = Number(process.env.PORT || 4000);
const DB_PATH = process.env.DB_PATH || path.join(projectRoot, 'turf.db');
const OWNER_PIN = process.env.OWNER_PIN || '';

const db = initDatabase(DB_PATH);

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon'
};

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-owner-pin'
  });
  res.end(JSON.stringify(payload, null, 2));
}

function sendError(res, statusCode, message, details = undefined) {
  sendJson(res, statusCode, { error: message, details });
}

async function readJsonBody(req) {
  let body = '';
  for await (const chunk of req) body += chunk;
  if (!body) return {};
  try {
    return JSON.parse(body);
  } catch {
    const error = new Error('Invalid JSON body.');
    error.statusCode = 400;
    throw error;
  }
}

function validateAvailabilityQuery(searchParams) {
  const date = searchParams.get('date');
  const sport = searchParams.get('sport');

  if (!isValidDateKey(date)) return { error: 'date must be in YYYY-MM-DD format.' };
  if (!isValidSport(sport)) return { error: 'sport must be football or cricket.' };

  return { date, sport };
}

function validateBookingPayload(payload) {
  const { date, slot, sport, customerName, phone } = payload;
  const errors = [];

  if (!isValidDateKey(date)) errors.push('date must be in YYYY-MM-DD format.');
  if (!isValidSlot(slot)) errors.push('slot is not valid.');
  if (!isValidSport(sport)) errors.push('sport must be football or cricket.');
  if (!customerName || String(customerName).trim().length < 2) errors.push('customerName must be at least 2 characters.');
  if (!isValidIndianPhone(phone)) errors.push('phone must be a valid 10-digit Indian mobile number.');

  return errors;
}

function ownerAllowed(req) {
  if (!OWNER_PIN) return true;
  return req.headers['x-owner-pin'] === OWNER_PIN;
}

async function handleApi(req, res, url) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, x-owner-pin'
    });
    return res.end();
  }

  if (req.method === 'GET' && url.pathname === '/api/health') {
    return sendJson(res, 200, { status: 'running', service: 'GreenField Turf API' });
  }

  if (req.method === 'GET' && url.pathname === '/api/config') {
    return sendJson(res, 200, { business: BUSINESS, sports: SPORTS, timeSlots: TIME_SLOTS });
  }

  if (req.method === 'GET' && url.pathname === '/api/availability') {
    const validated = validateAvailabilityQuery(url.searchParams);
    if (validated.error) return sendError(res, 400, validated.error);

    return sendJson(res, 200, {
      date: validated.date,
      sport: validated.sport,
      slots: db.getAvailability(validated.date, validated.sport)
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/bookings') {
    const payload = await readJsonBody(req);
    const errors = validateBookingPayload(payload);
    if (errors.length) return sendError(res, 400, 'Invalid booking request.', errors);

    const result = db.createBooking({
      date: payload.date,
      slot: payload.slot,
      sport: payload.sport,
      customerName: payload.customerName,
      phone: payload.phone,
      paymentStatus: payload.paymentStatus || 'paid'
    });

    if (!result.ok) return sendError(res, result.code === 'SLOT_ALREADY_BOOKED' || result.code === 'SLOT_BLOCKED' ? 409 : 400, result.message, { code: result.code });
    return sendJson(res, 201, { booking: result.booking });
  }

  if (req.method === 'GET' && url.pathname === '/api/bookings') {
    if (!ownerAllowed(req)) return sendError(res, 401, 'Owner PIN required.');
    const date = url.searchParams.get('date');
    if (!isValidDateKey(date)) return sendError(res, 400, 'date must be in YYYY-MM-DD format.');

    return sendJson(res, 200, { date, bookings: db.getBookings(date) });
  }

  if (req.method === 'POST' && url.pathname === '/api/admin/block-slot') {
    if (!ownerAllowed(req)) return sendError(res, 401, 'Owner PIN required.');
    const payload = await readJsonBody(req);
    const errors = validateBookingPayload({ ...payload, customerName: 'Owner', phone: '9876543210' });
    if (typeof payload.block !== 'boolean') errors.push('block must be true or false.');
    if (errors.length) return sendError(res, 400, 'Invalid block-slot request.', errors);

    const result = db.setBlockedSlot({
      date: payload.date,
      slot: payload.slot,
      sport: payload.sport,
      block: payload.block,
      reason: payload.reason || ''
    });

    if (!result.ok) return sendError(res, 409, result.message, { code: result.code });
    return sendJson(res, 200, { date: payload.date, sport: payload.sport, slots: result.availability });
  }

  return sendError(res, 404, 'API route not found.');
}

async function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';

  const requestedPath = path.normalize(path.join(publicDir, pathname));
  if (!requestedPath.startsWith(publicDir)) return sendError(res, 403, 'Forbidden.');

  try {
    const file = await readFile(requestedPath);
    const ext = path.extname(requestedPath);
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'application/octet-stream' });
    res.end(file);
  } catch {
    const fallback = await readFile(path.join(publicDir, 'index.html'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(fallback);
  }
}

export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
      return await serveStatic(req, res, url);
    } catch (error) {
      console.error(error);
      return sendError(res, error.statusCode || 500, error.message || 'Internal server error.');
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const server = createServer();
  server.listen(PORT, () => {
    console.log(`GreenField Turf website running at http://localhost:${PORT}`);
    console.log(`Database file: ${DB_PATH}`);
    if (OWNER_PIN) console.log('Owner panel PIN is enabled. Use the value from OWNER_PIN.');
    else console.log('Owner panel PIN is disabled for demo mode.');
  });

  process.on('SIGINT', () => {
    db.close();
    server.close(() => process.exit(0));
  });
}
