const app = document.querySelector('#app');

const state = {
  config: null,
  adminOpen: false,
  selectedDate: dateKey(new Date()),
  sport: 'football',
  selectedSlot: null,
  availability: [],
  bookings: [],
  step: 'browse',
  form: { name: '', phone: '' },
  confirmedBooking: null,
  loading: true,
  paying: false,
  alert: null,
  ownerPin: localStorage.getItem('ownerPin') || ''
};

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function dateKey(date) {
  return date.toISOString().slice(0, 10);
}

function getNextDays(count) {
  return Array.from({ length: count }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d;
  });
}

function slotLabel(slot) {
  const hour = Number(slot.split(':')[0]);
  const period = hour >= 12 ? 'PM' : 'AM';
  const display = hour % 12 === 0 ? 12 : hour % 12;
  return `${display}:00 ${period}`;
}

function dateLabel(dateString) {
  const d = new Date(`${dateString}T00:00:00`);
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

function isNight(slot) {
  const hour = Number(slot.split(':')[0]);
  return hour >= 18 || hour < 6;
}

function currentSport() {
  return state.config.sports.find((sport) => sport.id === state.sport);
}

function selectedAvailability() {
  return state.availability.find((slot) => slot.slot === state.selectedSlot);
}

function setAlert(type, message) {
  state.alert = { type, message };
  render();
}

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.ownerPin) headers['x-owner-pin'] = state.ownerPin;

  const response = await fetch(path, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const details = Array.isArray(data.details) ? ` ${data.details.join(' ')}` : '';
    throw new Error((data.error || 'Request failed.') + details);
  }
  return data;
}

async function loadConfig() {
  state.loading = true;
  render();
  try {
    state.config = await api('/api/config');
    await loadAvailability();
  } catch (error) {
    state.alert = { type: 'error', message: error.message };
  } finally {
    state.loading = false;
    render();
  }
}

async function loadAvailability() {
  const data = await api(`/api/availability?date=${state.selectedDate}&sport=${state.sport}`);
  state.availability = data.slots;
  if (state.selectedSlot) {
    const slot = state.availability.find((item) => item.slot === state.selectedSlot);
    if (!slot || slot.status !== 'open') state.selectedSlot = null;
  }
  if (state.adminOpen) await loadBookings();
}

async function loadBookings() {
  try {
    const data = await api(`/api/bookings?date=${state.selectedDate}`);
    state.bookings = data.bookings;
  } catch (error) {
    state.bookings = [];
    state.alert = { type: 'error', message: error.message };
  }
}

function setDate(date) {
  state.selectedDate = date;
  state.selectedSlot = null;
  state.alert = null;
  loadAvailability().then(render).catch((error) => setAlert('error', error.message));
}

function setSport(sport) {
  state.sport = sport;
  state.selectedSlot = null;
  state.alert = null;
  loadAvailability().then(render).catch((error) => setAlert('error', error.message));
}

function selectSlot(slot) {
  const item = state.availability.find((s) => s.slot === slot);
  if (!item || item.status !== 'open') return;
  state.selectedSlot = slot;
  state.alert = null;
  render();
}

function gotoStep(step) {
  state.step = step;
  state.alert = null;
  render();
}

function updateForm(field, value) {
  state.form[field] = field === 'phone' ? value.replace(/\D/g, '').slice(0, 10) : value;
  render();
}

async function confirmBooking() {
  if (!state.form.name.trim() || state.form.phone.length !== 10) {
    setAlert('error', 'Please enter a name and valid 10-digit phone number.');
    return;
  }

  state.paying = true;
  state.alert = null;
  render();

  try {
    const data = await api('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({
        date: state.selectedDate,
        slot: state.selectedSlot,
        sport: state.sport,
        customerName: state.form.name,
        phone: state.form.phone,
        paymentStatus: 'paid'
      })
    });

    state.confirmedBooking = data.booking;
    state.step = 'confirmed';
    await loadAvailability();
  } catch (error) {
    state.step = 'browse';
    await loadAvailability();
    state.alert = { type: 'error', message: error.message };
  } finally {
    state.paying = false;
    render();
  }
}

function resetBooking() {
  state.selectedSlot = null;
  state.form = { name: '', phone: '' };
  state.confirmedBooking = null;
  state.step = 'browse';
  loadAvailability().then(render).catch((error) => setAlert('error', error.message));
}

async function toggleAdmin() {
  state.adminOpen = !state.adminOpen;
  state.step = 'browse';
  state.alert = null;
  if (state.adminOpen) await loadBookings();
  render();
}

function setOwnerPin(value) {
  state.ownerPin = value.trim();
  localStorage.setItem('ownerPin', state.ownerPin);
  render();
}

async function toggleBlock(slot) {
  const item = state.availability.find((s) => s.slot === slot);
  if (!item || item.status === 'booked') return;

  try {
    const data = await api('/api/admin/block-slot', {
      method: 'POST',
      body: JSON.stringify({
        date: state.selectedDate,
        slot,
        sport: state.sport,
        block: item.status !== 'blocked',
        reason: 'Owner blocked slot'
      })
    });
    state.availability = data.slots;
    await loadBookings();
    state.alert = { type: 'success', message: item.status === 'blocked' ? 'Slot opened again.' : 'Slot blocked successfully.' };
    render();
  } catch (error) {
    setAlert('error', error.message);
  }
}

function html(strings, ...values) {
  return strings.reduce((acc, str, i) => acc + str + (values[i] ?? ''), '');
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function renderHeader() {
  const business = state.config?.business || { name: 'GreenField Turf', city: 'Lucknow', openLabel: 'Open 6 AM – 12 AM' };
  return html`
    <header class="header">
      <div class="header-inner">
        <div class="logo-wrap">
          <div class="logo-mark">GF</div>
          <div>
            <div class="logo-title">${escapeHtml(business.name).toUpperCase()}</div>
            <div class="logo-sub">${escapeHtml(business.city)} · ${escapeHtml(business.openLabel)}</div>
          </div>
        </div>
        <div class="owner-actions">
          <input class="owner-pin" type="password" placeholder="PIN" value="${escapeHtml(state.ownerPin)}" oninput="window.actions.setOwnerPin(this.value)" />
          <button class="owner-toggle" onclick="window.actions.toggleAdmin()">${state.adminOpen ? '← Back to site' : 'Owner panel'}</button>
        </div>
      </div>
    </header>
  `;
}

function renderHero() {
  return html`
    <section class="hero">
      <div class="hero-content">
        <div class="eyebrow">FLOODLIT · FULL-SIZE NETS · TURF READY</div>
        <h1>Book the pitch.<br />Play tonight.</h1>
        <p class="hero-sub">Premium 5-a-side football & box cricket turf. Pick a real slot below — it gets saved in the backend database after confirmation.</p>
      </div>
    </section>
  `;
}

function renderAlert() {
  if (!state.alert) return '';
  return `<div class="alert ${state.alert.type}">${escapeHtml(state.alert.message)}</div>`;
}

function renderDates() {
  return html`
    <div class="date-strip">
      ${getNextDays(7).map((d) => {
        const key = dateKey(d);
        return html`
          <button class="date-card ${key === state.selectedDate ? 'active' : ''}" onclick="window.actions.setDate('${key}')">
            <div class="date-weekday">${WEEKDAYS[d.getDay()]}</div>
            <div class="date-num">${d.getDate()}</div>
            <div class="date-month">${MONTHS[d.getMonth()]}</div>
          </button>
        `;
      }).join('')}
    </div>
  `;
}

function renderSportPills() {
  return html`
    <div class="pills">
      ${state.config.sports.map((sport) => html`
        <button class="pill ${sport.id === state.sport ? 'active' : ''}" onclick="window.actions.setSport('${sport.id}')">
          ${escapeHtml(sport.label)}
        </button>
      `).join('')}
    </div>
  `;
}

function renderSlots({ admin = false } = {}) {
  return html`
    <div class="scoreboard">
      <div class="scoreboard-head"><span>SLOT</span><span>${admin ? 'TAP TO TOGGLE' : 'STATUS'}</span></div>
      <div class="slot-grid">
        ${state.availability.map((item) => {
          const cls = [
            'slot',
            item.status === 'booked' ? 'booked' : '',
            item.status === 'blocked' ? 'blocked' : '',
            state.selectedSlot === item.slot ? 'selected' : ''
          ].join(' ');
          const disabled = item.status !== 'open' && !admin;
          const meta = item.status === 'open' ? (isNight(item.slot) ? 'NIGHT ⚡' : 'DAY') : item.status.toUpperCase();
          const click = admin ? `window.actions.toggleBlock('${item.slot}')` : `window.actions.selectSlot('${item.slot}')`;
          return html`
            <button class="${cls}" ${disabled ? 'disabled' : ''} onclick="${click}">
              <span class="slot-time">${slotLabel(item.slot)}</span>
              <span class="slot-meta">${meta} · ₹${item.price}</span>
            </button>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

function renderBrowse() {
  const sport = currentSport();
  const selected = selectedAvailability();
  return html`
    <section class="section">
      <div class="section-inner">
        <h2 class="section-title">Pick your slot</h2>
        ${renderSportPills()}
        <div class="price-legend">
          Day (6 AM–6 PM): <strong>₹${sport.dayPrice}</strong>/hr &nbsp;|&nbsp;
          Night (6 PM–12 AM): <strong>₹${sport.nightPrice}</strong>/hr
        </div>
        ${renderDates()}
        ${renderSlots()}
        ${state.selectedSlot && selected ? html`
          <div class="sticky-bar">
            <div>
              <div class="sticky-label">${slotLabel(state.selectedSlot)} · ${dateLabel(state.selectedDate)}</div>
              <div class="sticky-price">₹${selected.price} for 1 hour</div>
            </div>
            <button class="cta" onclick="window.actions.gotoStep('details')">Continue →</button>
          </div>
        ` : ''}
      </div>
    </section>
    ${renderAmenities()}
  `;
}

function renderSummary(extra = '') {
  const sport = currentSport();
  const selected = selectedAvailability();
  return html`
    <div class="summary">
      <div class="summary-top"><span>${escapeHtml(sport.label)}</span><span class="summary-price">₹${selected?.price || ''}</span></div>
      <div class="summary-bottom">${dateLabel(state.selectedDate)} · ${slotLabel(state.selectedSlot)} · 1 hour ${extra ? '· ' + escapeHtml(extra) : ''}</div>
    </div>
  `;
}

function renderDetails() {
  return html`
    <section class="section">
      <div class="narrow">
        <button class="back" onclick="window.actions.gotoStep('browse')">← Change slot</button>
        <h2 class="section-title">Your details</h2>
        ${renderSummary()}
        <div class="form">
          <label class="label">Full name
            <input class="input" value="${escapeHtml(state.form.name)}" placeholder="Rohan Sharma" oninput="window.actions.updateForm('name', this.value)" />
          </label>
          <label class="label">Phone number
            <input class="input" value="${escapeHtml(state.form.phone)}" maxlength="10" placeholder="98765 43210" oninput="window.actions.updateForm('phone', this.value)" />
          </label>
          <button class="cta full" onclick="window.actions.gotoStep('payment')">Proceed to payment →</button>
        </div>
      </div>
    </section>
  `;
}

function renderPayment() {
  const selected = selectedAvailability();
  return html`
    <section class="section">
      <div class="narrow">
        <button class="back" onclick="window.actions.gotoStep('details')" ${state.paying ? 'disabled' : ''}>← Edit details</button>
        <h2 class="section-title">Payment</h2>
        ${renderSummary(`${state.form.name} · ${state.form.phone}`)}
        <div class="pay-card">
          <div class="pay-badge">TEST MODE — BACKEND CONNECTED</div>
          <p class="pay-note">This button now calls the real backend and stores the booking in SQLite. Later, this exact step can be replaced with Razorpay order creation + payment signature verification.</p>
          <button class="cta full" onclick="window.actions.confirmBooking()" ${state.paying ? 'disabled' : ''}>
            ${state.paying ? 'Processing…' : `Pay ₹${selected?.price || 0} & confirm`}
          </button>
        </div>
      </div>
    </section>
  `;
}

function renderConfirmed() {
  const booking = state.confirmedBooking;
  return html`
    <section class="section">
      <div class="narrow confirm">
        <div class="check">✓</div>
        <h2 class="confirm-title">Slot's yours.</h2>
        <p class="pay-note">Booking ID <strong>${escapeHtml(booking.bookingId)}</strong> — saved in backend database.</p>
        <div class="ticket">
          ${ticketRow('Sport', currentSport().label)}
          ${ticketRow('Date', dateLabel(booking.date))}
          ${ticketRow('Time', slotLabel(booking.slot))}
          ${ticketRow('Name', booking.customerName)}
          ${ticketRow('Phone', booking.phone)}
          ${ticketRow('Paid', `₹${booking.price}`)}
        </div>
        <button class="cta full" onclick="window.actions.resetBooking()">Book another slot</button>
      </div>
    </section>
  `;
}

function ticketRow(label, value) {
  return html`<div class="ticket-row"><span class="ticket-label">${escapeHtml(label)}</span><span class="ticket-value">${escapeHtml(value)}</span></div>`;
}

function renderAmenities() {
  const items = [
    ['💡', 'Floodlit nights', 'Play till midnight under full LED coverage.'],
    ['🥤', 'Café on-site', 'Water, sports drinks & light snacks at the counter.'],
    ['🅿️', 'Free parking', 'Dedicated two & four-wheeler parking.'],
    ['🧤', 'Gear rental', 'Bibs, balls & cricket kits available on request.']
  ];
  return html`
    <section class="amenities">
      <div class="section-inner">
        <h2 class="section-title-light">On the ground</h2>
        <div class="amenity-grid">
          ${items.map(([icon, title, text]) => html`
            <div class="amenity">
              <div class="amenity-icon">${icon}</div>
              <div class="amenity-title">${title}</div>
              <div class="amenity-text">${text}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </section>
  `;
}

function renderAdmin() {
  const booked = state.availability.filter((item) => item.status === 'booked').length;
  const blocked = state.availability.filter((item) => item.status === 'blocked').length;
  const open = state.availability.filter((item) => item.status === 'open').length;

  return html`
    <section class="section">
      <div class="section-inner">
        <h2 class="section-title">Owner panel</h2>
        <p class="admin-note">This is connected to the same backend. Use it for viewing bookings and blocking slots for walk-ins or maintenance. Set OWNER_PIN in production.</p>
        ${renderSportPills()}
        ${renderDates()}
        <div class="admin-stats">
          <div class="admin-stat"><div class="admin-num">${booked}</div><div class="admin-label">Booked slots</div></div>
          <div class="admin-stat"><div class="admin-num">${blocked}</div><div class="admin-label">Blocked slots</div></div>
          <div class="admin-stat"><div class="admin-num">${open}</div><div class="admin-label">Open slots</div></div>
        </div>
        ${renderSlots({ admin: true })}
        <h2 class="section-title" style="margin-top:26px">Bookings for ${dateLabel(state.selectedDate)}</h2>
        <div class="booking-list">
          ${state.bookings.length ? state.bookings.map((booking) => html`
            <div class="booking-item">
              <div><strong>${slotLabel(booking.slot)}</strong> · ${escapeHtml(booking.sport)} · ${escapeHtml(booking.customerName)}</div>
              <div>₹${booking.price} · ${escapeHtml(booking.phone)}</div>
            </div>
          `).join('') : '<div class="pay-note">No bookings for this date yet.</div>'}
        </div>
      </div>
    </section>
  `;
}

function renderFooter() {
  return html`
    <footer class="footer">
      <div class="footer-inner">
        <span>GreenField Turf — Lucknow, UP</span><span>•</span><span>Full-stack demo: frontend + backend + SQLite</span>
      </div>
    </footer>
  `;
}

function renderMain() {
  if (state.loading || !state.config) return '<section class="section"><div class="section-inner loading">Loading website and backend availability…</div></section>';
  if (state.adminOpen) return renderAdmin();
  if (state.step === 'details') return renderDetails();
  if (state.step === 'payment') return renderPayment();
  if (state.step === 'confirmed' && state.confirmedBooking) return renderConfirmed();
  return renderHero() + renderBrowse();
}

function render() {
  app.innerHTML = renderHeader() + renderAlert() + renderMain() + renderFooter();
}

window.actions = {
  setDate,
  setSport,
  selectSlot,
  gotoStep,
  updateForm,
  confirmBooking,
  resetBooking,
  toggleAdmin,
  toggleBlock,
  setOwnerPin
};

render();
loadConfig();
